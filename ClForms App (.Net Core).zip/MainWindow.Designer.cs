﻿namespace $safeprojectname$
{
    public partial class MainWindow
    {
        /// <summary>
        /// Initialize components of Window as buttons, panels, etc.
        /// </summary>
        private void InitializeComponent()
        {
            Width = 80;
            Height = 20;
            Title = "MainWindow";
            AutoSize = false;
        }
    }
}
