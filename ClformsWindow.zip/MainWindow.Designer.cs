﻿namespace $rootnamespace$
{
    public partial class $safeitemname$
    {
        /// <summary>
        /// Initialize components of Window as buttons, panels, etc.
        /// </summary>
        private void InitializeComponent()
        {
            Width = 80;
            Height = 20;
            Title = "$safeitemname$";
            AutoSize = false;
        }
    }
}
