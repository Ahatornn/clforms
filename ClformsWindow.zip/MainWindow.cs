﻿using ClForms.Elements;

namespace $rootnamespace$
{
    /// <summary>
    /// The main Window of App
    /// </summary>
    public partial class $safeitemname$ : Window
    {
        /// <summary>
        /// Initialize a new instance <see cref="$safeitemname$"/>
        /// </summary>
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
